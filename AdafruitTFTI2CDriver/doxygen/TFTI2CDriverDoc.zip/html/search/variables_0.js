var searchData=
[
  ['touches',['touches',['../struct_t_s_vars.html#aa4b2d72953b1bc52bb48fdd6df1eae56',1,'TSVars']]],
  ['touchid',['touchID',['../struct_t_s_vars.html#aa95d6acdafd2bf125ea880030db651c7',1,'TSVars']]],
  ['touchx',['touchX',['../struct_t_s_vars.html#ae0e46508cefc39da074adc673146ae15',1,'TSVars']]],
  ['touchy',['touchY',['../struct_t_s_vars.html#a08c99f4dc61958a48bf53f6ada6887da',1,'TSVars']]]
];
