var searchData=
[
  ['getpoint',['getPoint',['../_adafruit_t_f_t_i2_c_driver_8c.html#aef07d60f80889c1c77f51ade2ccf9d75',1,'getPoint(TSVars *var):&#160;AdafruitTFTI2CDriver.c'],['../_adafruit_t_f_t_i2_c_driver_8h.html#aef07d60f80889c1c77f51ade2ccf9d75',1,'getPoint(TSVars *var):&#160;AdafruitTFTI2CDriver.c']]]
];
