var searchData=
[
  ['ft6206_5faddr',['FT6206_ADDR',['../_adafruit_t_f_t_reg_addrs_8h.html#aa017fe3d67740b30ff6cefc5a1676f94',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5fdefault_5fthresshold',['FT6206_DEFAULT_THRESSHOLD',['../_adafruit_t_f_t_reg_addrs_8h.html#a825be9f78eaae219716997947057c09d',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5fg_5fft5201id',['FT6206_G_FT5201ID',['../_adafruit_t_f_t_reg_addrs_8h.html#aebf00415b4af2deb72fe99d865891f50',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5fnum_5fx',['FT6206_NUM_X',['../_adafruit_t_f_t_reg_addrs_8h.html#a5801e9c557b3fe25dab4e84dd0204a4b',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5fnum_5fy',['FT6206_NUM_Y',['../_adafruit_t_f_t_reg_addrs_8h.html#aa660220e2827da3b207b843aa5eb40ea',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5freg_5fcalibrate',['FT6206_REG_CALIBRATE',['../_adafruit_t_f_t_reg_addrs_8h.html#ad8d52da57ab529cf673c8cc1f8a06484',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5freg_5fchipid',['FT6206_REG_CHIPID',['../_adafruit_t_f_t_reg_addrs_8h.html#a978f874e13f801f04493f92ff3f758f3',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5freg_5ffactorymode',['FT6206_REG_FACTORYMODE',['../_adafruit_t_f_t_reg_addrs_8h.html#a24937e3e88b53d2b9515536ae87e1989',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5freg_5ffirmvers',['FT6206_REG_FIRMVERS',['../_adafruit_t_f_t_reg_addrs_8h.html#a6c842589ea779801a2c2eeea4c25a7af',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5freg_5fmode',['FT6206_REG_MODE',['../_adafruit_t_f_t_reg_addrs_8h.html#aea1b85930e294da220e4bbbb32d2cef4',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5freg_5fnumtouches',['FT6206_REG_NUMTOUCHES',['../_adafruit_t_f_t_reg_addrs_8h.html#ab76c4c15ca7be957bb4183418e201180',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5freg_5fpointrate',['FT6206_REG_POINTRATE',['../_adafruit_t_f_t_reg_addrs_8h.html#abda531d153b141e3d2c66271cbee83ad',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5freg_5fthreshhold',['FT6206_REG_THRESHHOLD',['../_adafruit_t_f_t_reg_addrs_8h.html#a83046a5f75482c97027f8b5425c17ada',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5freg_5fvendid',['FT6206_REG_VENDID',['../_adafruit_t_f_t_reg_addrs_8h.html#a3e4b574165b800b485e3e9ad56c8527e',1,'AdafruitTFTRegAddrs.h']]],
  ['ft6206_5freg_5fworkmode',['FT6206_REG_WORKMODE',['../_adafruit_t_f_t_reg_addrs_8h.html#a892c5e6fa03a08906e50f144103de7ce',1,'AdafruitTFTRegAddrs.h']]]
];
