var searchData=
[
  ['readdata',['readData',['../_adafruit_t_f_t_i2_c_driver_8c.html#a7a56ca5f679fb95b7bc3e0b42a565b78',1,'readData(uint16_t *x, uint16_t *y, TSVars *var):&#160;AdafruitTFTI2CDriver.c'],['../_adafruit_t_f_t_i2_c_driver_8h.html#a7a56ca5f679fb95b7bc3e0b42a565b78',1,'readData(uint16_t *x, uint16_t *y, TSVars *var):&#160;AdafruitTFTI2CDriver.c']]],
  ['readregister8',['readRegister8',['../_adafruit_t_f_t_i2_c_driver_8c.html#a8061018a8acd7cce9315a71dbec8eaac',1,'readRegister8(uint8_t reg):&#160;AdafruitTFTI2CDriver.c'],['../_adafruit_t_f_t_i2_c_driver_8h.html#a8061018a8acd7cce9315a71dbec8eaac',1,'readRegister8(uint8_t reg):&#160;AdafruitTFTI2CDriver.c']]]
];
