var searchData=
[
  ['ts_5fpoint',['TS_Point',['../_adafruit_t_s_point_8h.html#a9702f2d7c29db86813cef86eba3cf155',1,'AdafruitTSPoint.h']]],
  ['tsvars',['TSVars',['../_adafruit_t_f_t_i2_c_driver_8h.html#ae72aeeeed77f062bbdff4fc5495ecaa7',1,'AdafruitTFTI2CDriver.h']]]
];
