var searchData=
[
  ['touched',['touched',['../_adafruit_t_f_t_i2_c_driver_8c.html#a7218d80782d9f42cdd4afb1adb505a05',1,'touched():&#160;AdafruitTFTI2CDriver.c'],['../_adafruit_t_f_t_i2_c_driver_8h.html#a7218d80782d9f42cdd4afb1adb505a05',1,'touched():&#160;AdafruitTFTI2CDriver.c']]]
];
