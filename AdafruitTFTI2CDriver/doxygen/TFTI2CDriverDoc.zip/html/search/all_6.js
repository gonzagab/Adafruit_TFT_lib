var searchData=
[
  ['writeregister8',['writeRegister8',['../_adafruit_t_f_t_i2_c_driver_8c.html#a6c5e0ff4618d3855d53e446dd5b90618',1,'writeRegister8(uint8_t reg, uint8_t val):&#160;AdafruitTFTI2CDriver.c'],['../_adafruit_t_f_t_i2_c_driver_8h.html#a6c5e0ff4618d3855d53e446dd5b90618',1,'writeRegister8(uint8_t reg, uint8_t val):&#160;AdafruitTFTI2CDriver.c']]]
];
