var searchData=
[
  ['touched',['touched',['../_adafruit_t_f_t_i2_c_driver_8c.html#a7218d80782d9f42cdd4afb1adb505a05',1,'touched():&#160;AdafruitTFTI2CDriver.c'],['../_adafruit_t_f_t_i2_c_driver_8h.html#a7218d80782d9f42cdd4afb1adb505a05',1,'touched():&#160;AdafruitTFTI2CDriver.c']]],
  ['touches',['touches',['../struct_t_s_vars.html#aa4b2d72953b1bc52bb48fdd6df1eae56',1,'TSVars']]],
  ['touchid',['touchID',['../struct_t_s_vars.html#aa95d6acdafd2bf125ea880030db651c7',1,'TSVars']]],
  ['touchx',['touchX',['../struct_t_s_vars.html#ae0e46508cefc39da074adc673146ae15',1,'TSVars']]],
  ['touchy',['touchY',['../struct_t_s_vars.html#a08c99f4dc61958a48bf53f6ada6887da',1,'TSVars']]],
  ['ts_5fpoint',['TS_Point',['../struct_t_s___point.html',1,'TS_Point'],['../_adafruit_t_s_point_8h.html#a9702f2d7c29db86813cef86eba3cf155',1,'TS_Point():&#160;AdafruitTSPoint.h']]],
  ['tsvars',['TSVars',['../struct_t_s_vars.html',1,'TSVars'],['../_adafruit_t_f_t_i2_c_driver_8h.html#ae72aeeeed77f062bbdff4fc5495ecaa7',1,'TSVars():&#160;AdafruitTFTI2CDriver.h']]]
];
