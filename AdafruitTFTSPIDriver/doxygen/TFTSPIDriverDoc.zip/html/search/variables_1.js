var searchData=
[
  ['cp437',['cp437',['../struct_t_f_t_vars.html#aad6b036182e1ca11b1856ac18f916407',1,'TFTVars']]],
  ['cs',['cs',['../struct_t_f_t_vars.html#a34d82933d6b232e82f57bcc42f045241',1,'TFTVars']]],
  ['cursor_5fx',['cursor_x',['../struct_t_f_t_vars.html#aed18f303a7d3af8dc2a72d160fe8dcc2',1,'TFTVars']]],
  ['cursor_5fy',['cursor_y',['../struct_t_f_t_vars.html#a41e7f18038ce1a39bb39bb8cc912dcfa',1,'TFTVars']]]
];
