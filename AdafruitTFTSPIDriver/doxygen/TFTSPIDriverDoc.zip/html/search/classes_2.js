var searchData=
[
  ['tftvars',['TFTVars',['../struct_t_f_t_vars.html',1,'']]],
  ['tsbuttonvars',['TSButtonVars',['../struct_t_s_button_vars.html',1,'']]]
];
