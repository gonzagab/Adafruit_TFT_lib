var searchData=
[
  ['dc',['dc',['../struct_t_f_t_vars.html#a9e9fa6cfe200a6ded2303e583e0f3868',1,'TFTVars']]],
  ['ddrx',['DDRx',['../struct_a_v_r_pin.html#adb042bbebace45c3a4c754d245e56b65',1,'AVRPin']]]
];
