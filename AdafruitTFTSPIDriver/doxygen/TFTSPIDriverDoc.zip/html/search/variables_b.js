var searchData=
[
  ['sclk',['sclk',['../struct_t_f_t_vars.html#ae4edb702d1738db936aa7adbfc5ce06c',1,'TFTVars']]]
];
