var searchData=
[
  ['mask',['mask',['../struct_a_v_r_pin.html#a65e4b0d1fdbf7f283c7960098cdfbda7',1,'AVRPin']]],
  ['miso',['miso',['../struct_t_f_t_vars.html#a0743c02a07fcf6c9f0189996d3fc88be',1,'TFTVars']]],
  ['mosi',['mosi',['../struct_t_f_t_vars.html#acd8d54cf531c902adaf564d6375828f2',1,'TFTVars']]]
];
