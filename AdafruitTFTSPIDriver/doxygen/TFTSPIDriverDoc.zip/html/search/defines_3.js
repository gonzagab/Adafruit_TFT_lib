var searchData=
[
  ['tft_5fheight',['TFT_HEIGHT',['../_adafruit_t_f_t_s_p_i_driver_8h.html#a1c2d2e1cd167f90b809c3450fd6f3434',1,'AdafruitTFTSPIDriver.h']]],
  ['tft_5fwidth',['TFT_WIDTH',['../_adafruit_t_f_t_s_p_i_driver_8h.html#a83af0cb652728913ff58da7133c692ea',1,'AdafruitTFTSPIDriver.h']]]
];
