var searchData=
[
  ['pinx',['PINx',['../struct_a_v_r_pin.html#a79484fa0ab59addfe52792d1af2bd783',1,'AVRPin']]],
  ['portx',['PORTx',['../struct_a_v_r_pin.html#a1199bc37a19e3683ccce8e1baa3969ed',1,'AVRPin']]]
];
