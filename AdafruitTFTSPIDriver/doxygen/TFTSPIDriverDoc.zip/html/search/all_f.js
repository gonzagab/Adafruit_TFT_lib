var searchData=
[
  ['textbgcolor',['textBGColor',['../struct_t_f_t_vars.html#a7f56d2069ee784086ac9b1203c25b6e9',1,'TFTVars']]],
  ['textcolor',['textColor',['../struct_t_s_button_vars.html#ac365a934d553142e3b63292679e3503f',1,'TSButtonVars::textColor()'],['../struct_t_f_t_vars.html#ae21d648a4c3d9a48db289b1ec285ff90',1,'TFTVars::textColor()']]],
  ['textsize',['textSize',['../struct_t_f_t_vars.html#a0aee7f2e640ddd75bd3e5ca8b8f72810',1,'TFTVars']]],
  ['tft_5fheight',['TFT_HEIGHT',['../_adafruit_t_f_t_s_p_i_driver_8h.html#a1c2d2e1cd167f90b809c3450fd6f3434',1,'AdafruitTFTSPIDriver.h']]],
  ['tft_5fwidth',['TFT_WIDTH',['../_adafruit_t_f_t_s_p_i_driver_8h.html#a83af0cb652728913ff58da7133c692ea',1,'AdafruitTFTSPIDriver.h']]],
  ['tftvars',['TFTVars',['../struct_t_f_t_vars.html',1,'TFTVars'],['../_adafruit_t_f_t_s_p_i_driver_8h.html#a3e55e622dbf4c502e9905ee01cccd05f',1,'TFTVars():&#160;AdafruitTFTSPIDriver.h']]],
  ['tsbuttonvars',['TSButtonVars',['../struct_t_s_button_vars.html',1,'TSButtonVars'],['../_adafruit_t_f_t_button_8h.html#a6e379c57c97f5d1d1e5709888a61b668',1,'TSButtonVars():&#160;AdafruitTFTButton.h']]]
];
