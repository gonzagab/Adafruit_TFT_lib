var searchData=
[
  ['inittft',['initTFT',['../_adafruit_t_f_t_s_p_i_driver_8c.html#a9a86efca7883234fd9c7ebdfb79faaea',1,'initTFT(TFTVars *var):&#160;AdafruitTFTSPIDriver.c'],['../_adafruit_t_f_t_s_p_i_driver_8h.html#a9a86efca7883234fd9c7ebdfb79faaea',1,'initTFT(TFTVars *var):&#160;AdafruitTFTSPIDriver.c']]],
  ['invertdisplay',['invertDisplay',['../_adafruit_t_f_t_s_p_i_driver_8c.html#a7c3fa4ee7ed32fc99c4531c1870dcd03',1,'invertDisplay(bool i, TFTVars *var):&#160;AdafruitTFTSPIDriver.c'],['../_adafruit_t_f_t_s_p_i_driver_8h.html#a7c3fa4ee7ed32fc99c4531c1870dcd03',1,'invertDisplay(bool i, TFTVars *var):&#160;AdafruitTFTSPIDriver.c']]]
];
