var searchData=
[
  ['tftvars',['TFTVars',['../_adafruit_t_f_t_s_p_i_driver_8h.html#a3e55e622dbf4c502e9905ee01cccd05f',1,'AdafruitTFTSPIDriver.h']]],
  ['tsbuttonvars',['TSButtonVars',['../_adafruit_t_f_t_button_8h.html#a6e379c57c97f5d1d1e5709888a61b668',1,'AdafruitTFTButton.h']]]
];
