var searchData=
[
  ['gettextbounds',['getTextBounds',['../_adafruit_t_f_t_s_p_i_driver_8c.html#a74a9407e67393e81fc840f526d779322',1,'getTextBounds(char *str, int16_t x, int16_t y, int16_t *x1, int16_t *y1, uint16_t *w, uint16_t *h, TFTVars *var):&#160;AdafruitTFTSPIDriver.c'],['../_adafruit_t_f_t_s_p_i_driver_8h.html#ad70b916a9ead7ce45cf679c814874a50',1,'getTextBounds(char *string, int16_t x, int16_t y, int16_t *x1, int16_t *y1, uint16_t *w, uint16_t *h, TFTVars *var):&#160;AdafruitTFTSPIDriver.c']]],
  ['gfxfont',['GFXfont',['../struct_g_f_xfont.html',1,'GFXfont'],['../struct_t_f_t_vars.html#a626dbe8464c13404897e1c74254104dd',1,'TFTVars::gfxFont()']]],
  ['gfxfont_2eh',['GFXFont.h',['../_g_f_x_font_8h.html',1,'']]],
  ['gfxglyph',['GFXglyph',['../struct_g_f_xglyph.html',1,'']]],
  ['glyph',['glyph',['../struct_g_f_xfont.html#af63d88fa053c9a634e86eab7c96db290',1,'GFXfont']]]
];
