var searchData=
[
  ['textbgcolor',['textBGColor',['../struct_t_f_t_vars.html#a7f56d2069ee784086ac9b1203c25b6e9',1,'TFTVars']]],
  ['textcolor',['textColor',['../struct_t_s_button_vars.html#ac365a934d553142e3b63292679e3503f',1,'TSButtonVars::textColor()'],['../struct_t_f_t_vars.html#ae21d648a4c3d9a48db289b1ec285ff90',1,'TFTVars::textColor()']]],
  ['textsize',['textSize',['../struct_t_f_t_vars.html#a0aee7f2e640ddd75bd3e5ca8b8f72810',1,'TFTVars']]]
];
