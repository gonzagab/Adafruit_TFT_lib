var searchData=
[
  ['bitmap',['bitmap',['../struct_g_f_xfont.html#a867b14d604450addbeaf62ae1e4799a7',1,'GFXfont']]],
  ['bitmapoffset',['bitmapOffset',['../struct_g_f_xglyph.html#a24d52036821c10af52a742a1d7fbd9b8',1,'GFXglyph']]]
];
