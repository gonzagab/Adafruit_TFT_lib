var searchData=
[
  ['x',['x',['../struct_t_s_button_vars.html#adabcf574daf6ec1fae86877a1d4ca008',1,'TSButtonVars']]],
  ['xadvance',['xAdvance',['../struct_g_f_xglyph.html#a9b191040252aa9b5362087d65366bbf2',1,'GFXglyph']]],
  ['xoffset',['xOffset',['../struct_g_f_xglyph.html#ab030bd9aeb37509ccc94ae3dcec4de98',1,'GFXglyph']]]
];
