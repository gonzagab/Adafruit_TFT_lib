var searchData=
[
  ['w',['w',['../struct_t_s_button_vars.html#afee576f3d2c40433495e7e26fe49ebee',1,'TSButtonVars']]],
  ['width',['width',['../struct_t_f_t_vars.html#af74cf54cbe7c92de8ceab455e6148b46',1,'TFTVars::width()'],['../struct_g_f_xglyph.html#a02bd34fd474af250b230f52cee75a6c1',1,'GFXglyph::width()']]],
  ['wrap',['wrap',['../struct_t_f_t_vars.html#a4ace5fa1c8cd6f56555a77bf8059bc0b',1,'TFTVars']]],
  ['write',['write',['../_adafruit_t_f_t_s_p_i_driver_8c.html#a7de85ebdd02841dc0439f81565525919',1,'write(uint8_t c, TFTVars *var):&#160;AdafruitTFTSPIDriver.c'],['../_adafruit_t_f_t_s_p_i_driver_8h.html#a7de85ebdd02841dc0439f81565525919',1,'write(uint8_t c, TFTVars *var):&#160;AdafruitTFTSPIDriver.c']]],
  ['writecolor',['writeColor',['../_adafruit_t_f_t_s_p_i_driver_8c.html#a031df40a0b621ed0e13a1f3a1d0d309e',1,'writeColor(uint16_t color, uint32_t len, TFTVars *var):&#160;AdafruitTFTSPIDriver.c'],['../_adafruit_t_f_t_s_p_i_driver_8h.html#a031df40a0b621ed0e13a1f3a1d0d309e',1,'writeColor(uint16_t color, uint32_t len, TFTVars *var):&#160;AdafruitTFTSPIDriver.c']]],
  ['writecommandtft',['writeCommandTFT',['../_adafruit_t_f_t_s_p_i_driver_8c.html#a2965bd7fbaf384a899a8f150865dd1ca',1,'writeCommandTFT(uint8_t cmd, TFTVars *var):&#160;AdafruitTFTSPIDriver.c'],['../_adafruit_t_f_t_s_p_i_driver_8h.html#a2965bd7fbaf384a899a8f150865dd1ca',1,'writeCommandTFT(uint8_t cmd, TFTVars *var):&#160;AdafruitTFTSPIDriver.c']]],
  ['writepixels',['writePixels',['../_adafruit_t_f_t_s_p_i_driver_8c.html#a93c10b09a572230ccf28597598326978',1,'writePixels(uint16_t *colors, uint32_t len, TFTVars *var):&#160;AdafruitTFTSPIDriver.c'],['../_adafruit_t_f_t_s_p_i_driver_8h.html#a93c10b09a572230ccf28597598326978',1,'writePixels(uint16_t *colors, uint32_t len, TFTVars *var):&#160;AdafruitTFTSPIDriver.c']]]
];
