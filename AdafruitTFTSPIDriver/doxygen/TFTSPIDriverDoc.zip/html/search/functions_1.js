var searchData=
[
  ['charbounds',['charBounds',['../_adafruit_t_f_t_s_p_i_driver_8c.html#ad2fff048d73b3290ff2a60ffcad8d06d',1,'charBounds(char c, int16_t *x, int16_t *y, int16_t *minx, int16_t *miny, int16_t *maxx, int16_t *maxy, TFTVars *var):&#160;AdafruitTFTSPIDriver.c'],['../_adafruit_t_f_t_s_p_i_driver_8h.html#ad2fff048d73b3290ff2a60ffcad8d06d',1,'charBounds(char c, int16_t *x, int16_t *y, int16_t *minx, int16_t *miny, int16_t *maxx, int16_t *maxy, TFTVars *var):&#160;AdafruitTFTSPIDriver.c']]],
  ['color565',['color565',['../_adafruit_t_f_t_s_p_i_driver_8c.html#a86ff537d89af36245ba96933508ee634',1,'color565(uint8_t r, uint8_t g, uint8_t b):&#160;AdafruitTFTSPIDriver.c'],['../_adafruit_t_f_t_s_p_i_driver_8h.html#a86ff537d89af36245ba96933508ee634',1,'color565(uint8_t r, uint8_t g, uint8_t b):&#160;AdafruitTFTSPIDriver.c']]]
];
