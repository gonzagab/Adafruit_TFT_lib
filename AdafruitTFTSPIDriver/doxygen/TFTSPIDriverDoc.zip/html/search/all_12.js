var searchData=
[
  ['y',['y',['../struct_t_s_button_vars.html#af8786da14bcada953f31f2399fe6d20a',1,'TSButtonVars']]],
  ['yadvance',['yAdvance',['../struct_g_f_xfont.html#ac2c2f0184b810a562be808fbb98822fa',1,'GFXfont']]],
  ['yoffset',['yOffset',['../struct_g_f_xglyph.html#a96b2c0dbe314bf053cdc0d5c622e76a7',1,'GFXglyph']]]
];
