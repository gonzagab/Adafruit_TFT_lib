var searchData=
[
  ['gettextbounds',['getTextBounds',['../_adafruit_t_f_t_s_p_i_driver_8c.html#a74a9407e67393e81fc840f526d779322',1,'getTextBounds(char *str, int16_t x, int16_t y, int16_t *x1, int16_t *y1, uint16_t *w, uint16_t *h, TFTVars *var):&#160;AdafruitTFTSPIDriver.c'],['../_adafruit_t_f_t_s_p_i_driver_8h.html#ad70b916a9ead7ce45cf679c814874a50',1,'getTextBounds(char *string, int16_t x, int16_t y, int16_t *x1, int16_t *y1, uint16_t *w, uint16_t *h, TFTVars *var):&#160;AdafruitTFTSPIDriver.c']]]
];
