var searchData=
[
  ['rotation',['rotation',['../struct_t_f_t_vars.html#a610c6fea289d857fa54eab7f9d1ec45d',1,'TFTVars']]],
  ['rst',['rst',['../struct_t_f_t_vars.html#aa6a6519059e0590fa51bffc2de45da15',1,'TFTVars']]]
];
