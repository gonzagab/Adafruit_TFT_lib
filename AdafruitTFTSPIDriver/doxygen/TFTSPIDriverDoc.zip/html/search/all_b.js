var searchData=
[
  ['outlinecolor',['outlineColor',['../struct_t_s_button_vars.html#a0655af30b92e30676d275d6e400a8d17',1,'TSButtonVars']]]
];
