var searchData=
[
  ['bitmap',['bitmap',['../struct_g_f_xfont.html#a867b14d604450addbeaf62ae1e4799a7',1,'GFXfont']]],
  ['bitmapoffset',['bitmapOffset',['../struct_g_f_xglyph.html#a24d52036821c10af52a742a1d7fbd9b8',1,'GFXglyph']]],
  ['buttoncontainspointtft',['buttonContainsPointTFT',['../_adafruit_t_f_t_button_8c.html#ae257208e45427c9a5c1f143fd4235720',1,'buttonContainsPointTFT(int16_t x, int16_t y, TSButtonVars *button):&#160;AdafruitTFTButton.c'],['../_adafruit_t_f_t_button_8h.html#ae257208e45427c9a5c1f143fd4235720',1,'buttonContainsPointTFT(int16_t x, int16_t y, TSButtonVars *button):&#160;AdafruitTFTButton.c']]]
];
